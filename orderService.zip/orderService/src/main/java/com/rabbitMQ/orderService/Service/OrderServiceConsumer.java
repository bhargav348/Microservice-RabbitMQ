package com.rabbitMQ.orderService.Service;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import com.rabbitMQ.orderService.configuration.OrderServiceRabbitMQConfig;
import com.rabbitMQ.orderService.model.CustomerRequest;
@Component
public class OrderServiceConsumer {

	
	@RabbitListener(queues=OrderServiceRabbitMQConfig.QUEUE)
	public void consumerCustomerOrderServiceQueue(CustomerRequest customerRequest) {
		System.out.println(customerRequest.getCustomerCity());
		System.out.println(customerRequest.getCustomerMobile());
		System.out.println(customerRequest.getCustomerName());
		
	}
}
